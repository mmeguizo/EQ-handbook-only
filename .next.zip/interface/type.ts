export interface EnvVariables {
  GEMINI_API_KEY: string;
  ASTRA_DB_APPLICATION_TOKEN: string;
  ASTRA_DB_COLLECTION: string;
  ASTRA_DB_NAMESPACE: string;
  ASTRA_DB_API_ENDPOINT: string;
}
