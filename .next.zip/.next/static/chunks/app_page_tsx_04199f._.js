(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_7b1584._.js",
    "static/chunks/_c061a4._.js"
  ],
  "source": "dynamic"
});
