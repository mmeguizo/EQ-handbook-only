export default function PromptSuggestionRow() {
  return (
    <>
      <span>PromptSuggestionRow</span>
    </>
  );
}
