export default function Bubble() {
  return (
    <>
      <span>Bubble</span>
    </>
  );
}
