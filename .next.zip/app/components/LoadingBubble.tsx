export default function LoadingBubble() {
  return (
    <>
      <span>LoadingBubble</span>
    </>
  );
}
